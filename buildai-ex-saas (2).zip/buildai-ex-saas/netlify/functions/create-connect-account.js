// Crée (ou récupère) le compte Stripe Connect Express d'un tenant
// et renvoie un lien d'onboarding pour qu'il renseigne son RIB, son identité, etc.
const Stripe = require('stripe');
const { createClient } = require('@supabase/supabase-js');

const stripe = Stripe(process.env.STRIPE_SECRET_KEY);
const supabase = createClient(process.env.SUPABASE_URL, process.env.SUPABASE_SERVICE_ROLE_KEY);

exports.handler = async (event) => {
  if (event.httpMethod !== 'POST') return { statusCode: 405, body: 'Method not allowed' };

  try {
    const { tenant_id, email } = JSON.parse(event.body);

    const { data: tenant, error } = await supabase
      .from('tenants').select('*').eq('id', tenant_id).single();
    if (error || !tenant) return { statusCode: 404, body: 'Boutique introuvable' };

    let accountId = tenant.stripe_account_id;
    if (!accountId) {
      const account = await stripe.accounts.create({ type: 'express', email });
      accountId = account.id;
      await supabase.from('tenants').update({ stripe_account_id: accountId }).eq('id', tenant_id);
    }

    const accountLink = await stripe.accountLinks.create({
      account: accountId,
      refresh_url: `${process.env.SITE_URL}/dashboard.html?onboarding=refresh`,
      return_url: `${process.env.SITE_URL}/dashboard.html?onboarding=success`,
      type: 'account_onboarding',
    });

    return { statusCode: 200, body: JSON.stringify({ url: accountLink.url }) };
  } catch (err) {
    return { statusCode: 500, body: JSON.stringify({ error: err.message }) };
  }
};
