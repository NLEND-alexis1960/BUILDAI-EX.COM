// Reçoit la description en langage naturel de l'activité du client,
// demande à Claude de générer le contenu du site (titre, présentation,
// sections, et si pertinent une liste de produits suggérés), puis
// enregistre le résultat dans tenants.site_content.
const { createClient } = require('@supabase/supabase-js');

const supabase = createClient(process.env.SUPABASE_URL, process.env.SUPABASE_SERVICE_ROLE_KEY);

const SYSTEM_PROMPT = `Tu es le moteur de génération de site de BuildAI-EX.
On te donne la description en langage naturel d'une activité (TPE, PME,
freelance, e-commerce ou particulier). Tu dois renvoyer UNIQUEMENT un
objet JSON valide, sans texte avant ni après, sans balises markdown,
au format exact suivant :

{
  "headline": "titre principal accrocheur, 6-10 mots",
  "tagline": "une phrase de sous-titre, 12-20 mots",
  "about": "paragraphe de présentation, 40-70 mots",
  "sections": [
    {"title": "titre de section", "body": "contenu, 25-40 mots"},
    {"title": "titre de section", "body": "contenu, 25-40 mots"},
    {"title": "titre de section", "body": "contenu, 25-40 mots"}
  ],
  "is_ecommerce": true,
  "suggested_products": [
    {"name": "...", "description": "...", "price_eur": 0}
  ]
}

Mets "is_ecommerce" à false et "suggested_products" à [] si l'activité
ne vend pas de produits en ligne (ex : service, portfolio, association).
Adapte le ton à l'activité décrite. Réponds en français.`;

exports.handler = async (event) => {
  if (event.httpMethod !== 'POST') return { statusCode: 405, body: 'Method not allowed' };

  try {
    const { tenant_id, business_description } = JSON.parse(event.body);
    if (!business_description || business_description.trim().length < 5) {
      return { statusCode: 400, body: JSON.stringify({ error: 'Décrivez votre activité avant de générer le site.' }) };
    }

    const response = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-api-key': process.env.ANTHROPIC_API_KEY,
        'anthropic-version': '2023-06-01',
      },
      body: JSON.stringify({
        model: 'claude-sonnet-4-6',
        max_tokens: 1200,
        system: SYSTEM_PROMPT,
        messages: [{ role: 'user', content: business_description }],
      }),
    });

    const data = await response.json();
    const raw = data.content?.[0]?.text || '';
    const cleaned = raw.replace(/```json|```/g, '').trim();
    const siteContent = JSON.parse(cleaned);

    if (tenant_id) {
      await supabase.from('tenants').update({ site_content: siteContent }).eq('id', tenant_id);
    }

    return { statusCode: 200, body: JSON.stringify({ site_content: siteContent }) };
  } catch (err) {
    return { statusCode: 500, body: JSON.stringify({ error: "La génération a échoué : " + err.message }) };
  }
};
