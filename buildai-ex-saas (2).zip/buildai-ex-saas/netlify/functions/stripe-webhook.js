// Stripe appelle cette fonction automatiquement quand un paiement est confirmé.
// C'est ce qui garantit que la commande n'est marquée "payée" que si
// l'argent a vraiment été reçu (jamais faire confiance au navigateur du client).
const Stripe = require('stripe');
const { createClient } = require('@supabase/supabase-js');

const stripe = Stripe(process.env.STRIPE_SECRET_KEY);
const supabase = createClient(process.env.SUPABASE_URL, process.env.SUPABASE_SERVICE_ROLE_KEY);

exports.handler = async (event) => {
  const sig = event.headers['stripe-signature'];
  let stripeEvent;

  try {
    stripeEvent = stripe.webhooks.constructEvent(event.body, sig, process.env.STRIPE_WEBHOOK_SECRET);
  } catch (err) {
    return { statusCode: 400, body: `Erreur de signature webhook : ${err.message}` };
  }

  if (stripeEvent.type === 'checkout.session.completed') {
    const session = stripeEvent.data.object;
    await supabase
      .from('orders')
      .update({ status: 'paid' })
      .eq('stripe_checkout_session_id', session.id);
  }

  return { statusCode: 200, body: 'ok' };
};
