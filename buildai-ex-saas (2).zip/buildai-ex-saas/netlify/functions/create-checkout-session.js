// Reçoit le panier du client, calcule le total, et crée une session
// Stripe Checkout. L'argent va directement sur le compte Stripe du
// tenant (transfer_data.destination) ; BuildAI-EX prélève une commission
// automatique (application_fee_amount) — exactement comme une marketplace.
const Stripe = require('stripe');
const { createClient } = require('@supabase/supabase-js');

const stripe = Stripe(process.env.STRIPE_SECRET_KEY);
const supabase = createClient(process.env.SUPABASE_URL, process.env.SUPABASE_SERVICE_ROLE_KEY);

const PLATFORM_FEE_PERCENT = 5; // commission BuildAI-EX, ajustable

exports.handler = async (event) => {
  if (event.httpMethod !== 'POST') return { statusCode: 405, body: 'Method not allowed' };

  try {
    const { tenant_id, items, customer_email } = JSON.parse(event.body);
    // items attendu : [{ product_id, quantity }, ...]

    const { data: tenant } = await supabase
      .from('tenants').select('stripe_account_id').eq('id', tenant_id).single();
    if (!tenant?.stripe_account_id) {
      return { statusCode: 400, body: JSON.stringify({ error: "Cette boutique n'a pas encore connecté Stripe." }) };
    }

    const productIds = items.map(i => i.product_id);
    const { data: products } = await supabase.from('products').select('*').in('id', productIds);

    let amountTotal = 0;
    const line_items = items.map(item => {
      const product = products.find(p => p.id === item.product_id);
      amountTotal += product.price_cents * item.quantity;
      return {
        price_data: {
          currency: product.currency,
          product_data: { name: product.name },
          unit_amount: product.price_cents,
        },
        quantity: item.quantity,
      };
    });

    const applicationFee = Math.round(amountTotal * (PLATFORM_FEE_PERCENT / 100));

    const session = await stripe.checkout.sessions.create({
      mode: 'payment',
      line_items,
      customer_email,
      payment_intent_data: {
        application_fee_amount: applicationFee,
        transfer_data: { destination: tenant.stripe_account_id },
      },
      success_url: `${process.env.SITE_URL}/store.html?tenant=${tenant_id}&success=1`,
      cancel_url: `${process.env.SITE_URL}/store.html?tenant=${tenant_id}&canceled=1`,
    });

    await supabase.from('orders').insert({
      tenant_id,
      customer_email,
      stripe_checkout_session_id: session.id,
      amount_total: amountTotal,
      currency: products[0]?.currency || 'eur',
      status: 'pending',
    });

    return { statusCode: 200, body: JSON.stringify({ url: session.url }) };
  } catch (err) {
    return { statusCode: 500, body: JSON.stringify({ error: err.message }) };
  }
};
