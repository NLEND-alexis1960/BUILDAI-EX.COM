-- ============================================================
-- BuildAI-EX — Schéma de base de données (Supabase / Postgres)
-- À exécuter dans : Supabase > SQL Editor > New query
-- ============================================================

create extension if not exists "uuid-ossp";

-- Une "tenant" = une entreprise / un freelance / un particulier
-- qui a créé sa boutique/site avec BuildAI-EX
create table tenants (
  id uuid primary key default uuid_generate_v4(),
  owner_id uuid references auth.users(id) not null,
  business_name text not null,
  slug text unique not null,               -- utilisé dans l'URL de la boutique
  stripe_account_id text,                  -- compte Stripe Connect du tenant
  stripe_onboarded boolean default false,
  site_content jsonb,                      -- contenu du site généré par l'IA
  created_at timestamptz default now()
);

create table products (
  id uuid primary key default uuid_generate_v4(),
  tenant_id uuid references tenants(id) on delete cascade not null,
  name text not null,
  description text,
  price_cents integer not null,
  currency text default 'eur',
  image_url text,
  stock integer default 0,
  active boolean default true,
  created_at timestamptz default now()
);

create table orders (
  id uuid primary key default uuid_generate_v4(),
  tenant_id uuid references tenants(id) not null,
  customer_email text,
  stripe_checkout_session_id text unique,
  amount_total integer,
  currency text,
  status text default 'pending',           -- pending | paid | failed
  created_at timestamptz default now()
);

create table order_items (
  id uuid primary key default uuid_generate_v4(),
  order_id uuid references orders(id) on delete cascade not null,
  product_id uuid references products(id),
  quantity integer not null,
  unit_price_cents integer not null
);

-- ============================================================
-- Sécurité : Row Level Security
-- Chaque tenant ne voit/modifie que ses propres données.
-- Les visiteurs peuvent lire les produits actifs (catalogue public).
-- ============================================================
alter table tenants enable row level security;
alter table products enable row level security;
alter table orders enable row level security;
alter table order_items enable row level security;

create policy "tenants_owner_full_access" on tenants
  for all using (auth.uid() = owner_id);

create policy "products_public_read" on products
  for select using (active = true);

create policy "products_owner_manage" on products
  for all using (tenant_id in (select id from tenants where owner_id = auth.uid()));

create policy "orders_owner_read" on orders
  for select using (tenant_id in (select id from tenants where owner_id = auth.uid()));

create policy "order_items_owner_read" on order_items
  for select using (
    order_id in (
      select id from orders where tenant_id in (
        select id from tenants where owner_id = auth.uid()
      )
    )
  );
