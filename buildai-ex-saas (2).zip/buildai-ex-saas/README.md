# BuildAI-EX — SaaS complet (génération IA, base de données, panier, paiements Stripe)

Ce projet donne à BuildAI-EX une vraie fondation multi-clients : chaque
entreprise, PME, freelance ou particulier peut créer son compte, gérer
ses produits, et être payé directement sur son propre compte Stripe.
BuildAI-EX prélève automatiquement une petite commission sur chaque vente
(5 % par défaut, modifiable dans `netlify/functions/create-checkout-session.js`).

## Architecture

```
public/               → pages du site (aucune compilation nécessaire)
  index.html           – page vitrine
  dashboard.html        – espace client : ajout de produits, connexion Stripe
  store.html             – boutique publique : catalogue + panier + paiement
netlify/functions/     → code serveur (jamais visible du client)
  generate-site.js            – génération du contenu du site par l'IA (le cœur du projet)
  create-connect-account.js  – onboarding Stripe du vendeur
  create-checkout-session.js – création du paiement
  stripe-webhook.js           – confirmation officielle du paiement
supabase/schema.sql    → structure de la base de données
```

## Mise en route (environ 20 minutes)

### 1. Créer la base de données (Supabase — gratuit)
1. Créez un compte sur supabase.com et un nouveau projet.
2. Dans **SQL Editor**, collez le contenu de `supabase/schema.sql` et exécutez-le.
3. Dans **Project Settings > API**, récupérez :
   - `Project URL` → à coller dans `public/dashboard.html` et `public/store.html` (variable `SUPABASE_URL`)
   - `anon public key` → variable `SUPABASE_ANON_KEY` (mêmes fichiers)
   - `service_role key` → à garder secrète, elle va dans Netlify (jamais dans le HTML)

### 2. Activer la génération IA
1. Créez une clé API sur console.anthropic.com (Settings > API Keys).
2. Ajoutez-la comme variable Netlify `ANTHROPIC_API_KEY` (voir étape 3 du déploiement).

### 3. Créer le compte Stripe (plateforme)
1. Créez un compte sur stripe.com.
2. Activez **Stripe Connect** (Dashboard > Connect > Get started, type "Express").
3. Récupérez votre clé secrète (`sk_live_...` ou `sk_test_...` pour tester).

### 4. Déployer sur Netlify
1. Poussez ce dossier sur un dépôt GitHub, puis "Add new site > Import an existing project" sur Netlify.
   (Ou glissez le dossier sur app.netlify.com/drop pour un premier test rapide — les fonctions serveur nécessitent toutefois un dépôt Git pour fonctionner.)
2. Dans **Site settings > Environment variables**, ajoutez les valeurs de `.env.example`.
3. Déployez. Netlify installe automatiquement `stripe` et `@supabase/supabase-js`.

### 5. Configurer le webhook Stripe
1. Dashboard Stripe > Developers > Webhooks > Add endpoint.
2. URL : `https://votre-site.netlify.app/api/stripe-webhook`
3. Événement à écouter : `checkout.session.completed`
4. Copiez le "Signing secret" dans la variable `STRIPE_WEBHOOK_SECRET`.

## Parcours utilisateur

1. Un client va sur `dashboard.html`, crée un compte → une "boutique" (tenant) est créée automatiquement.
2. Il décrit son activité en langage naturel → l'IA génère le contenu de son site (titre, présentation, sections) et, si pertinent, une liste de produits suggérés qu'il peut ajouter en un clic.
3. Il clique sur "Connecter Stripe" → renseigne son identité/RIB via Stripe (aucune donnée bancaire ne transite par vos serveurs).
4. Il ajuste ses produits si besoin.
5. Sa boutique publique est accessible via `store.html?tenant=SON_ID`, avec le contenu généré par l'IA affiché en en-tête.
6. Un acheteur ajoute au panier, paie par carte → l'argent va directement sur le compte Stripe du vendeur, moins la commission BuildAI-EX.

## Ce qui reste à faire pour une V1 commerciale

- Régénération / édition manuelle du contenu généré par l'IA (actuellement, un clic écrase le contenu précédent).
- Domaine personnalisé par client (actuellement une seule URL Netlify avec `?tenant=...`).
- Gestion du stock en temps réel, factures, emails automatiques.
- Plan d'abonnement BuildAI-EX (Stripe Billing) en plus de la commission par vente.
- Génération d'une image/logo par l'IA en plus du texte.
